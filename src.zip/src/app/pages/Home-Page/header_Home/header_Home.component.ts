import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header_Home',
  templateUrl: './header_Home.component.html',
  styleUrls: ['./header_Home.component.css']
})
export class header_HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
