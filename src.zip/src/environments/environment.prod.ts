export const environment = {
  production: true,
  // api_url : "https://customapi.shoplocal-lagunabeach.com",
  api_url:''

};
